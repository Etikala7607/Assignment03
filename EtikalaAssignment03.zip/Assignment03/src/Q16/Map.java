package Q16;

import java.util.HashMap;

public class Map {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
HashMap<Integer, String> Hm = new HashMap<Integer, String>();
Hm.put(1, "Sravan");
Hm.put(2, "Ram");
Hm.put(3, "Sunny");
System.out.println("HashMap"+ Hm);
String value = Hm.get(1);
System.out.println("value at index 1" +value);
	}

}
