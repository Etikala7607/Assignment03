package Q20;


public class StatesThread implements Runnable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StatesThread st = new StatesThread();
		Thread t1 = new Thread(st);
		t1.start();
		t1.interrupt();
}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Run the Thread");
	}
}
