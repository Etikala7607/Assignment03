package Q13;

import java.util.ArrayList;
import java.util.Iterator;

public class Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList al = new ArrayList();
al.add(1);
al.add(2);
System.out.println(al.size());


	}

}
