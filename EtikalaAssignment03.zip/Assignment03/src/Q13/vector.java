package Q13;

import java.util.Vector;

public class vector {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Vector v1 = new Vector();
v1.add(1);
v1.add(2);
v1.add(3);
System.out.println(v1);

	}

}
