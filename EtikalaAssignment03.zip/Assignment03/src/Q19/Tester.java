package Q19;

public class Tester extends Thread {
public void run() {
	System.out.println("Run the Thread");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Tester t1 = new Tester();
Thread t2 = new Thread(t1);
t2.start();
	}

}
