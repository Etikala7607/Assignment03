package Q19;



public class ImpThread  implements Runnable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 ImpThread r1 = new  ImpThread();
		 
		 Thread t1 = new Thread(r1);
		 
		 t1.start();
		 
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Run the thread");
	}

}
