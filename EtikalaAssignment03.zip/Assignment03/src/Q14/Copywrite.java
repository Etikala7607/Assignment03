package Q14;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class Copywrite {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CopyOnWriteArrayList<String> al =
	            new CopyOnWriteArrayList<String>();
		al.add("Sravan");
		al.add("Ram");
		al.add("Sunny");
		Iterator<String> itr = al.iterator();
		 
        while (itr.hasNext())
        {
            String str = itr.next();
            itr.remove();
		
	}

}
}
