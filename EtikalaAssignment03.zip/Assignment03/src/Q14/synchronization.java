package Q14;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;



public class synchronization {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList al = new ArrayList();
		al.add("Sravan");
		al.add("Ram");
		al.add("Sunny");
al = (ArrayList) Collections.synchronizedList(al);
synchronized(al) {
	Iterator itr = al.iterator();
	while (itr.hasNext()) {
		System.out.println(al);
	}
}

	
}

	}


