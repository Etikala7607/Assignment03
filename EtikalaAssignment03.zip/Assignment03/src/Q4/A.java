package Q4;

public class A {
private void display(){
	System.out.println("OverRide");
}
}
