package Q4;

public class B extends A{
  void display() {
	 System.out.println("It cannot overRide");
  }
  
	public static void main(String[] args) {
		// TODO Auto-generated method stub
A obj = new B();
obj.display();
	}

}
