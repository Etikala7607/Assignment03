package Q17;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class FailFast {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String, String> empName = new HashMap<String, String>();   
        empName.put("Sravan", "New york");   
        empName.put("ram", "LA");   
        empName.put("Sunny", "Chicago");   
        Iterator iterator = empName.keySet().iterator();   
        while (iterator.hasNext()) {   
            System.out.println(empName.get(iterator.next()));   
            
            empName.put("Istanbul", "Turkey"); 
	}

}
}
