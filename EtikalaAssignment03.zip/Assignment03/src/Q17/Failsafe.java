package Q17;

import java.util.ArrayList;
import java.util.Iterator;

public class Failsafe {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

        ArrayList<Integer> list   
            = new ArrayList<Integer>();   
        list.add(1);
        list.add(2);
        list.add(3);
        
        Iterator itr = list.iterator();
        while (itr.hasNext()) {   
            Integer i = (Integer)itr.next();   
            System.out.println(i);   
            if (i == 7)   
                list.add(15);
	}

}
}
