package Q5;

public class StringBuffer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   StringBuffer buffer=new StringBuffer();  
	        buffer.getClass();  
	        System.out.println(buffer);
	}

}
