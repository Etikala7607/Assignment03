package Q5;

public class StringBuilder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
StringBuilder b1 = new StringBuilder();
b1.getClass();
	}

}
