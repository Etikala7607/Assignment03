package Q6;

public class StringClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String S = new String("Hello");
String add = S.concat("World");
System.out.println(add);
	}

}
