package Q18;

public class Test implements Runnable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Test r1 = new Test();
				 
				 Thread t1 = new Thread(r1);
				 
				 t1.start();
				 t1.start();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Run the Thread");
	}

}
