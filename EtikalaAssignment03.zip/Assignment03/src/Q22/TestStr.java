package Q22;

public class TestStr {

	public static void main(java.lang.String[] args) {
		// TODO Auto-generated method stub
		 String s1 = "Sravan";
	        s1.concat(" rules");
	 
	       
	        System.out.println("s1 refers to " + s1);
	    }
	}


