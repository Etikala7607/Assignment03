package Q10;

import java.io.FileNotFoundException;

public class ThrowDriver {
	
		public void add () throws FileNotFoundException{
			System.out.println("Method of add class");
			
		}


		public class exception extends ThrowDriver{
			public void substract() {
				System.out.println("method of subclass");
			}
		}
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
ThrowDriver T1 = new ThrowDriver();

	}

	}

