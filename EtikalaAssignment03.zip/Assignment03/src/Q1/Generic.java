package Q1;

public class Generic<  > {
	private E data;
	public Generic (E data) {
		this.data = data;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Generic<String> g1 = new Generic<>("I am learning the java");
		System.out.println("Generic returns:"+g1.data);
	}

}
