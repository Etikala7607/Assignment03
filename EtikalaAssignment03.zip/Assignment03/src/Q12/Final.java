package Q12;

public final  class Final {
  int a =1 ;
 static int b =2;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
 Final f1 = new Final();
 
 System.out.println(f1.a);
	}

}