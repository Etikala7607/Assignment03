package Q7;

public class Constructor {
	int numbers = 10;
	String a = "java";
	
	 public Final Constructor(int numbers, String a) {

		this.numbers = numbers;
		this.a = a;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

 
Constructor c1 = new Constructor();
System.out.println(c1.a);

	}

}
