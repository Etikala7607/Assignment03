package Q15;

import java.util.HashMap;
import java.util.Map;

public class hash {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<String, String> hm = new HashMap<String, String>();
		hm.put("Sravan", "Good");
		hm.put("Ram", "worse");
		hm.put("Sunny", "best");
		for(Map.Entry m: hm.entrySet()) {
			System.out.println(m.getKey());
		}

		
	}

}
