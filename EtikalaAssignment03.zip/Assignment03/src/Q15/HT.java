package Q15;

import java.util.Hashtable;
import java.util.Map;

public class HT {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hashtable<Integer, Integer> Ht = new Hashtable<Integer,Integer>();
		Ht.put(1,22);
		Ht.put(2,33);
		Ht.put(3, 44);
		for(Map.Entry t:Ht.entrySet());
		System.out.println(Ht.contains(33));
	}

}
