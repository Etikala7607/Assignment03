package Q8;

public class Try {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try {
	                    System.out.println("JAva");
} finally {
	System.out.println("Error");
}
	}

}
